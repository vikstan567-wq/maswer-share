# maswer share
Upload a big file, get a shareable link. Developed by Vivek Singh.

## Run
    npm install
    npm start          # http://localhost:3000

## Settings (environment variables)
- PORT        default 3000
- MAX_MB      max file size in MB, default 500
- UPLOAD_DIR  where files are stored, default ./uploads

## Make the link work for other people
Run it on a server they can reach (VPS, Render, Railway, etc.), then open that site's address.
Links are made from the address you opened the site on.
For quick testing from your own PC, a tunnel such as `cloudflared tunnel --url http://localhost:3000` gives a public address.

Files auto-delete after 1, 7 or 30 days (chosen at upload).
