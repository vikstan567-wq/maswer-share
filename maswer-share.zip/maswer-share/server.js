// maswer share - Developed by Vivek Singh
const express = require('express');
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const MAX_MB = Number(process.env.MAX_MB || 500);          // max file size
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
const EXPIRY_DAYS = { '1': 1, '7': 7, '30': 30 };

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const app = express();
app.set('trust proxy', true);
app.use(express.static(path.join(__dirname, 'public')));

const newId = () => crypto.randomBytes(6).toString('base64url');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const human = (b) => {
  const u = ['B', 'KB', 'MB', 'GB']; let i = 0; let n = b;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return n.toFixed(i ? 1 : 0) + ' ' + u[i];
};
const baseUrl = (req) => `${req.protocol}://${req.get('host')}`;
const metaPath = (id) => path.join(UPLOAD_DIR, id, 'meta.json');
const readMeta = (id) => {
  if (!/^[A-Za-z0-9_-]{6,16}$/.test(id)) return null;
  try {
    const m = JSON.parse(fs.readFileSync(metaPath(id), 'utf8'));
    if (Date.now() > m.expiresAt) { removeUpload(id); return null; }
    return m;
  } catch { return null; }
};
const removeUpload = (id) => fs.rmSync(path.join(UPLOAD_DIR, id), { recursive: true, force: true });

// ---- Upload (streams straight to disk, so 100 MB+ is fine) ----
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    req.uploadId = newId();
    const dir = path.join(UPLOAD_DIR, req.uploadId);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => cb(null, 'data'),
});
const upload = multer({ storage, limits: { fileSize: MAX_MB * 1024 * 1024, files: 1 } }).single('file');

app.post('/api/upload', (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      if (req.uploadId) removeUpload(req.uploadId);
      const tooBig = err.code === 'LIMIT_FILE_SIZE';
      return res.status(tooBig ? 413 : 500).json({ error: tooBig ? `File is larger than ${MAX_MB} MB.` : 'Upload failed. Try again.' });
    }
    if (!req.file) return res.status(400).json({ error: 'No file received.' });
    const days = EXPIRY_DAYS[req.body.expiry] || 7;
    const meta = {
      id: req.uploadId,
      name: path.basename(req.file.originalname).replace(/[\r\n"]/g, '_'),
      size: req.file.size,
      type: req.file.mimetype,
      createdAt: Date.now(),
      expiresAt: Date.now() + days * 86400000,
      deleteToken: crypto.randomBytes(12).toString('hex'),
      downloads: 0,
    };
    fs.writeFileSync(metaPath(meta.id), JSON.stringify(meta));
    res.json({
      id: meta.id,
      name: meta.name,
      size: meta.size,
      link: `${baseUrl(req)}/f/${meta.id}`,
      directLink: `${baseUrl(req)}/d/${meta.id}`,
      expiresAt: meta.expiresAt,
      deleteToken: meta.deleteToken,
    });
  });
});

app.delete('/api/delete/:id', (req, res) => {
  const m = readMeta(req.params.id);
  if (!m || req.query.token !== m.deleteToken) return res.status(403).json({ error: 'Not allowed.' });
  removeUpload(m.id);
  res.json({ ok: true });
});

// ---- Download ----
app.get('/d/:id', (req, res) => {
  const m = readMeta(req.params.id);
  if (!m) return res.status(404).send(page('Link not found', `<p class="muted">This link has expired or was deleted.</p><a class="btn" href="/">Share a new file</a>`));
  m.downloads++;
  fs.writeFile(metaPath(m.id), JSON.stringify(m), () => {});
  res.download(path.join(UPLOAD_DIR, m.id, 'data'), m.name);
});

app.get('/f/:id', (req, res) => {
  const m = readMeta(req.params.id);
  if (!m) return res.status(404).send(page('Link not found', `<p class="muted">This link has expired or was deleted.</p><a class="btn" href="/">Share a new file</a>`));
  const left = Math.max(1, Math.ceil((m.expiresAt - Date.now()) / 86400000));
  res.send(page('Your file is ready', `
    <div class="filebox">
      <div class="fname">${esc(m.name)}</div>
      <div class="muted">${human(m.size)} &middot; expires in ${left} day${left > 1 ? 's' : ''}</div>
    </div>
    <a class="btn" href="/d/${m.id}">Download file</a>`));
});

function page(title, body) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} - maswer share</title><link rel="stylesheet" href="/style.css"></head>
<body><main class="card narrow">
<img class="logo" src="/logo.png" alt="maswer"><h1>${esc(title)}</h1>${body}</main>
<footer>Developed by Vivek Singh</footer></body></html>`;
}

// ---- Cleanup of expired files, every 30 min ----
setInterval(() => {
  for (const id of fs.readdirSync(UPLOAD_DIR)) readMeta(id);
}, 30 * 60 * 1000);

app.listen(PORT, () => console.log(`maswer share running on http://localhost:${PORT} (max ${MAX_MB} MB)`));
